﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BBDemo
{
    public interface IAlgo
    {
        public void NextStep(BBox box);
    }
}
